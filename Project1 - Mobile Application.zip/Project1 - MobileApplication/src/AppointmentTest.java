import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    // Test - that appointment can be created with valid information
    @Test
    public void testAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date appointmentDate = calendar.getTime();

        Appointment appointment = new Appointment(
            "APT100", appointmentDate, "Client meeting"
        );

        assertEquals("APT100", appointment.getAppointmentId());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals("Client meeting", appointment.getDescription());
    }

    // Test - that an appointment ID is not null or no longer than 10 characters
    @Test
    public void testAppointmentId() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date appointmentDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, appointmentDate, "Client meeting")
        );

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("APPOINTMENT1", appointmentDate, "Client meeting")
        );
    }

    // Test - that an appointment date is not null or in the past
    @Test
    public void testAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("APT100", null, "Client meeting")
        );

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        Date pastDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("APT100", pastDate, "Client meeting")
        );
    }

    // Test - that a description is not null or longer than 50 characters
    @Test
    public void testDescription() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date appointmentDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("APT100", appointmentDate, null)
        );

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "APT100",
                appointmentDate,
                "This appointment description is longer than fifty characters"
            )
        );
    }
}