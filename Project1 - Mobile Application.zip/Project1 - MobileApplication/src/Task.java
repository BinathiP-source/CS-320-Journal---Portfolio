public class Task {

	// Store information

	private String taskId;
	private String name;
	private String description;
	public Task(String taskId, String name, String description) {

		// Reject invalid information and display error message

		if (taskId == null || taskId.length() > 10) {
		    throw new IllegalArgumentException("Invalid task ID");

		}

		if (name == null || name.length() > 20) {
		    throw new IllegalArgumentException("Invalid task name");

		}

		if (description == null || description.length() > 50) {
		    throw new IllegalArgumentException("Invalid task description");

		}


		// Stores information as a task

	    this.taskId = taskId;
	    this.name = name;
	    this.description = description;

	}

	public String getTaskId() {
	    return taskId;

	}

	public String getName() {
	    return name;

	}

	public String getDescription() {
	    return description;

	}


	// Allow information to be updated and checks if the new information is valid to be updated.

	public void setName(String name) {
	    if (name == null || name.length() > 20) {
	        throw new IllegalArgumentException("Invalid task name");

	    }

	    this.name = name;

	}

	public void setDescription(String description) {
	    if (description == null || description.length() > 50) {
	        throw new IllegalArgumentException("Invalid task description");

	    }

	    this.description = description;

	}

}