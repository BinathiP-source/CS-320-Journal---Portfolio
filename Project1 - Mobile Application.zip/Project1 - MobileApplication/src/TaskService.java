import java.util.HashMap;
import java.util.Map;

public class TaskService {

    // Stores tasks
    private Map<String, Task> tasks = new HashMap<>();

    // Add task with a unique ID 
    public void addTask(Task task) {

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }

        tasks.put(task.getTaskId(), task);
    }

    // Delete a task using task ID
    public void deleteTask(String taskId) {

        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.remove(taskId);
    }

    // Update the name using task ID
    public void updateName(String taskId, String name) {

        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.get(taskId).setName(name);
    }

    // Update the description using task ID
    public void updateDescription(String taskId, String description) {

        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.get(taskId).setDescription(description);
    }
}