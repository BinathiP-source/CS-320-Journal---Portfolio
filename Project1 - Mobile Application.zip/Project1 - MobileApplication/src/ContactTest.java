import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Tests that a contact can be created using valid information
    @Test
    public void testContact() {
        Contact contact = new Contact(
            "123",
            "Maya",
            "Chen",
            "1234567890",
            "Rock Drive"
        );

        assertEquals("123", contact.getContactId());
        assertEquals("Maya", contact.getFirstName());
        assertEquals("Chen", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("Rock Drive", contact.getAddress());
    }

    // Tests that invalid contact information is not created and rejected
    @Test
    public void testInvalidContact() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "Maya", "Chen", "1234567890", "Rock Drive"));

        assertThrows(IllegalArgumentException.class, () ->
            new Contact("123", "Maya", "Chen", "12345", "Rock Drive"));
    }

    // Tests that contacts can be updated
    @Test
    public void testUpdateFields() {
        Contact contact = new Contact(
            "123",
            "Maya",
            "Chen",
            "1234567890",
            "Rock Drive"
        );

        contact.setFirstName("Nora");
        contact.setLastName("Patel");
        contact.setPhone("0987654321");
        contact.setAddress("Snow Avenue");

        assertEquals("Nora", contact.getFirstName());
        assertEquals("Patel", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("Snow Avenue", contact.getAddress());
    }
}