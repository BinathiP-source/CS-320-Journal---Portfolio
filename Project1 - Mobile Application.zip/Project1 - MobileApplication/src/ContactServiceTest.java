import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private Contact createContact() {
        return new Contact(
            "ID123",
            "Maya",
            "Chen",
            "1234567890",
            "Rock Drive"
        );
    }

    // Tests that a contact can be added as unique contact ID 
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);

        // Test to see that same contact ID added as a duplicate contact
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(contact));
    }

    // Test so contacts can be deleted using their unique contact ID
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);
        service.deleteContact("ID123");

        
        assertThrows(IllegalArgumentException.class, () ->
            service.updateFirstName("ID123", "Nora"));
    }

    // Test that contacts can be updated
    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);

        service.updateFirstName("ID123", "Nora");
        service.updateLastName("ID123", "Patel");
        service.updatePhone("ID123", "0987654321");
        service.updateAddress("ID123", "Snow Avenue");

        assertEquals("Nora", contact.getFirstName());
        assertEquals("Patel", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("Snow Avenue", contact.getAddress());
    }
}