import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    // Stores all appointments using their IDs
    private Map<String, Appointment> appointments = new HashMap<>();

    // Adds a new appointment with unique ID
    public void addAppointment(Appointment appointment) {

        // Check if appointment exists in this ID
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete an appointment using ID
    public void deleteAppointment(String appointmentId) {

        // Check if an appointment exists with this ID
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }

        // Remove appointment
        appointments.remove(appointmentId);
    }
}
