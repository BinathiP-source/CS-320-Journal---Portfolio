import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // Create a task for test
    private Task createTask() {
        return new Task(
            "SKE1",
            "Concept Sketch",
            "Create a concept sketch of a game environment"
        );
    }

    // Test - task can be created and added with a unique ID
    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = createTask();

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () ->
            service.addTask(task));
    }

    // Test -  Task can be deleted using its ID
    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = createTask();

        service.addTask(task);
        service.deleteTask("SKE1");

        assertThrows(IllegalArgumentException.class, () ->
            service.updateName("SKE1", "Environment Sketch"));
    }

    // Test that a task name and description can be updated
    @Test
    public void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = createTask();

        service.addTask(task);

        service.updateName("SKE1", "Environment Sketch");
        service.updateDescription("SKE1", "Sketch a fantasy game environment");

        assertEquals("Environment Sketch", task.getName());
        assertEquals("Sketch a fantasy game environment", task.getDescription());
    }
}