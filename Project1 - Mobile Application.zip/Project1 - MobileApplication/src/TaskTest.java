import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // Test - Task can be created with Valid Task information of ID, name and description
    @Test
    public void testTask() {
        Task task = new Task(
            "SKE1",
            "Concept Sketch",
            "Create a concept sketch of a game environment"
        );

        assertEquals("SKE1", task.getTaskId());
        assertEquals("Concept Sketch", task.getName());
        assertEquals("Create a concept sketch of a game environment", task.getDescription());
    }

    // Test - verifies that invalid information is rejected
    @Test
    public void testInvalidTask() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Concept Sketch", "Create a concept sketch of a game environment"));
    }

    // Test - name and description can be updated
    @Test
    public void testUpdateTask() {
        Task task = new Task(
            "SKE1",
            "Concept Sketch",
            "Create a concept sketch of a game environment"
        );

        task.setName("Environment Sketch");
        task.setDescription("Sketch a fantasy game environment");

        assertEquals("Environment Sketch", task.getName());
        assertEquals("Sketch a fantasy game environment", task.getDescription());
    }
}