import java.util.HashMap;
import java.util.Map;

public class ContactService {

	    // Stores contacts
	    private Map<String, Contact> contacts = new HashMap<>();

	    // Adds a contact with a unique ID
	    public void addContact(Contact contact) {

	        if (contacts.containsKey(contact.getContactId())) {
	            throw new IllegalArgumentException("Contact ID already exists");
	        }

	        contacts.put(contact.getContactId(), contact);
	    }

	    // Deletes a contact using contact ID
	    public void deleteContact(String contactId) {

	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact ID not found");
	        }

	        contacts.remove(contactId);
	    }

	    // Use contact ID to update the first name 
	    public void updateFirstName(String contactId, String firstName) {

	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact ID not found");
	        }

	        contacts.get(contactId).setFirstName(firstName);
	    }

	    // Use contact ID to update the last name 
	    public void updateLastName(String contactId, String lastName) {

	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact ID not found");
	        }

	        contacts.get(contactId).setLastName(lastName);
	    }

	    // Use contact ID to update the phone number 
	    public void updatePhone(String contactId, String phone) {

	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact ID not found");
	        }

	        contacts.get(contactId).setPhone(phone);
	    }

	    // Use contact ID to update the address 
	    public void updateAddress(String contactId, String address) {

	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact ID not found");
	        }

	        contacts.get(contactId).setAddress(address);
	    }
}
