import java.util.Date;

public class Appointment {
	
	// Store appointment information & finalize values to prevent them from being reassigned
	private final String appointmentId;
	private final Date appointmentDate;
	private final String description;
	
	public Appointment(String appointmentId, Date appointmentDate, String description) {
		
		// Reject invalid information and display error message
		
		// check that appointmentID length is limited to 10 characters and is not null
		if (appointmentId == null || appointmentId.length() > 10) {
		    throw new IllegalArgumentException("Invalid appointment ID");
		}
		
		// Check that appointment date is not in the past and is not null
		if (appointmentDate == null || appointmentDate.before(new Date())) {
		    throw new IllegalArgumentException("Invalid appointment date");
		}
		
		// check that description is limited to 50 characters and is not null
		if (description == null || description.length() > 50) {
		    throw new IllegalArgumentException("Invalid description");
		}
		
		// Store valid information as an appointment
	    this.appointmentId = appointmentId;
	    this.appointmentDate = new Date(appointmentDate.getTime());
	    this.description = description;
	}
	
	// Return information
	
	public String getAppointmentId() {
	    return appointmentId;
	}
	
	public Date getAppointmentDate() {
	    return new Date(appointmentDate.getTime());
	}

	public String getDescription() {
	    return description;
	}
	
}
