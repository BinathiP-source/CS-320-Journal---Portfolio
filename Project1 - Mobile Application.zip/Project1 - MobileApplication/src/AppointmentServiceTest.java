import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    // Test - that appointment can be added with unique appointment ID
    @Test
    public void testAddAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date appointmentDate = calendar.getTime();

        AppointmentService service = new AppointmentService();

        service.addAppointment(new Appointment(
            "APT100", appointmentDate, "Client meeting"
        ));

        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(new Appointment(
                "APT100", appointmentDate, "Project meeting"
            ))
        );
    }

    // Test - that an appointment can be deleted using ID
    @Test
    public void testDeleteAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date appointmentDate = calendar.getTime();

        AppointmentService service = new AppointmentService();

        service.addAppointment(new Appointment(
            "APT100", appointmentDate, "Client meeting"
        ));

        service.deleteAppointment("APT100");

        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment("APT100")
        );
    }
}